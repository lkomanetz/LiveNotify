(function() {
    var btnApply = null;
    var lblCurrentHandle = null;
    var txtHandle = null;

    document.addEventListener("DOMContentLoaded", defineHandle_WindowLoaded);
    
    function defineHandle_WindowLoaded() {
        $("#dialogForm").dialog({
            autoOpen: true,
            height: 200,
            width: 300,
            modal: true
        });
        btnApply = document.getElementById("btnApply");
        lblCurrentHandle = document.getElementById("lblCurrentHandle");
        txtHandle = document.getElementById("txtHandle");

        btnApply.addEventListener("click", btnApply_Clicked);
        txtHandle.addEventListener("input", txtHandle_TextChanged);

        chrome.storage.sync.get("liveNotifyHandle", function (storageItem) {
            if (storageItem.liveNotifyHandle !== undefined) {
                lblCurrentHandle.innerText = "@" + storageItem.liveNotifyHandle;
            }
            else {
                lblCurrentHandle.innerText = storageItem.liveNotifyHandle;
            }
        });
    }

    function btnApply_Clicked() {
        lblCurrentHandle.innerText = "@" + txtHandle.value;
        saveHandle();
    }

    function txtHandle_TextChanged(evt) {
        var nonAlphaNumericRegex = /[^\w]+/g;
        var currentText = evt.currentTarget.value.replace(nonAlphaNumericRegex, "");
        if (currentText !== "") {
            btnApply.disabled = false;
        }
        else {
            btnApply.disabled = true;
        }
        evt.currentTarget.value = currentText.toLowerCase();
    }

    function saveHandle() {
        var currentHandle = lblCurrentHandle.innerText.replace("@", "");
        chrome.storage.sync.set({"liveNotifyHandle": currentHandle}, function () {});
    }
})();
